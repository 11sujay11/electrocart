// ================= PRODUCT DATA =================
const products = [
    {
        id: 1,
        name: "iPhone 15 Pro",
        price: 1299,
        image: "https://via.placeholder.com/250?text=iPhone+15+Pro",
        category: "mobile"
    },
    {
        id: 2,
        name: "Samsung S24 Ultra",
        price: 1199,
        image: "https://via.placeholder.com/250?text=S24+Ultra",
        category: "mobile"
    },
    {
        id: 3,
        name: "OnePlus 13",
        price: 899,
        image: "https://via.placeholder.com/250?text=OnePlus+13",
        category: "mobile"
    },
    {
        id: 4,
        name: "Apple Watch Ultra 2",
        price: 799,
        image: "https://via.placeholder.com/250?text=Apple+Watch+Ultra",
        category: "watch"
    },
    {
        id: 5,
        name: "Samsung Watch 7",
        price: 349,
        image: "https://via.placeholder.com/250?text=Samsung+Watch+7",
        category: "watch"
    },
    {
        id: 6,
        name: "Realme Watch X",
        price: 199,
        image: "https://via.placeholder.com/250?text=Realme+Watch+X",
        category: "watch"
    }
];

// ================= CART FUNCTIONALITY =================
let cart = [];

function displayProducts() {
    const container = document.getElementById("product-container");
    container.innerHTML = "";

    products.forEach(product => {
        container.innerHTML += `
        <div class="product-card">
            <img src="${product.image}" alt="">
            <h3>${product.name}</h3>
            <p>$${product.price}</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        </div>`;
    });
}

function addToCart(id) {
    const product = products.find(item => item.id === id);
    cart.push(product);
    updateCartCount();
    alert(product.name + " added to your cart!");
}

function updateCartCount() {
    document.getElementById("cart-count").innerText = cart.length;
}

document.addEventListener("DOMContentLoaded", () => {
    displayProducts();
    updateCartCount();
});


// ================= SEARCH FUNCTIONALITY =================
function searchProducts() {
    const searchValue = document.getElementById("search-box").value.toLowerCase();
    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchValue)
    );
    showSearchResults(filteredProducts);
}

function showSearchResults(data) {
    const container = document.getElementById("product-container");
    container.innerHTML = "";

    if (data.length === 0) {
        container.innerHTML = "<p>No products found!</p>";
        return;
    }

    data.forEach(product => {
        container.innerHTML += `
        <div class="product-card">
            <img src="${product.image}" alt="">
            <h3>${product.name}</h3>
            <p>$${product.price}</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        </div>`;
    });
}


// ================ CATEGORY FILTER =================
function filterProducts(category) {
    if (category === "all") {
        displayProducts();
        return;
    }

    const data = products.filter(item => item.category === category);
    showSearchResults(data);
}
